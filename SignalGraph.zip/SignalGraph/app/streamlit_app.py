import streamlit as st, pandas as pd, pathlib
st.set_page_config(page_title="SignalGraph 5G", layout="wide")
root = pathlib.Path(__file__).resolve().parents[1]
silver = root / "data" / "silver" / "cell_kpi_minute"
st.title("SignalGraph 5G — Analyst View")
st.caption("Filter a small synthetic slice and preview anomalies before adding ML and graph analytics.")
if not silver.exists():
    st.warning("Silver data not found. Run the Spark Bronze→Silver step first.")
else:
    files = list(silver.glob("date=*/region=*/part-*.parquet"))
    if not files:
        st.warning("No parquet files detected in Silver.")
    else:
        df = pd.concat([pd.read_parquet(f) for f in files[:4]], ignore_index=True)
        region = st.selectbox("Region", sorted(df["region"].unique().tolist()))
        df_r = df[df["region"] == region]
        st.metric("Rows loaded", f"{len(df_r):,}")
        st.dataframe(df_r[["ts","cell_id","anomaly_flag","latency_ms","prb_util_pct","thrpt_mbps"]].sort_values("ts").head(100))
        top = (df_r.groupby("cell_id")[["anomaly_flag","latency_ms","prb_util_pct"]]
               .mean().sort_values("anomaly_flag", ascending=False).reset_index().head(10))
        st.subheader("Top cells by anomaly rate")
        st.dataframe(top)
        st.markdown("Next steps: add XGBoost risk score, Prophet latency forecast, and a neighbor graph drill-in.")
