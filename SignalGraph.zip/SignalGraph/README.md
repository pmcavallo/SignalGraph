# SignalGraph 5G — Verizon‑Aligned Network AI Demo

A compact, interview‑ready system that ingests 4G/5G RF and IP KPIs, builds lakehouse tables on top of Hadoop‑style partitions, engineers features, scores cell risk, renders a small analyst UI, and exposes a clear demo script.

## Why it matters for Verizon
- Maps to large‑scale analytics, Hadoop, lakehouse, NoSQL, and graph requirements. 
- Uses ML baselines that are transparent for risk and operations.
- Shows system performance thinking via partitioning, p95 metrics, and data quality checks.

## Demo flow
1. Load a small synthetic KPI slice into Bronze, convert to Silver with Spark, and preview Gold schema.
2. Open Streamlit to list top‑risk cells by simple rules and visualize a timeline placeholder.
3. Walk through the interview questions using the included talking points.

## Roadmap
- Gold table, XGBoost scoring, Prophet capacity forecasts
- Neo4j neighbor graph and centrality
- DuckDB and Postgres mirrors of Teradata marts
- EMR or Dataproc runbooks with YARN submission

## Repo structure (incremental)
```
SignalGraph/
  README.md
  requirements.txt
  data/raw/
  data/sim/
  spark/bronze_to_silver.py
  app/streamlit_app.py
  sql/postgres/
  neo4j/
  dq/
```

## Interview hooks
- Why Hadoop and Parquet for performance and cost
- Why partitioning by date and region
- How you would scale to real telemetry volume
- How graph centrality prioritizes fixes when multiple cells degrade
